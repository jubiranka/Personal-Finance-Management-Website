<?php
    error_reporting(0);//because two session start were in the code
    include_once("sql/userConnection.php");


    $allBorrow = "SELECT * FROM `borrow` ORDER BY `borrow_return_date` DESC";
    $allLent = "SELECT * FROM `lent` ORDER BY `lent_return_date` DESC";
    $allInvestment = "SELECT * FROM `investment` ORDER BY `investment_maturity` DESC";
    $allInvestementQuery = mysqli_query($conDb,$allInvestment);
    $allBorrowQuery = mysqli_query($conDb,$allBorrow);
    $allLentQuery = mysqli_query($conDb,$allLent);

    $currentDate = date("Y-m-d");


?>

<div class="container-fluid split">
    <div class="container">
            <div class="commonDC" id="splitShow">
                <div class="listOfSplit">
                    <div class="month" id="borrowNotifictionList">
                        <h5 class="text-black">Borrowed</h5> 
                        <ul>
                            <?php
                                if(mysqli_num_rows($allBorrowQuery) > 0){
                                    while($data = mysqli_fetch_array($allBorrowQuery)){
                                        if($data['status'] != "settled"){
                                            if($data['borrow_return_date'] < $currentDate){
                            ?>
                            <li>
                                <div class="splitDetails" borrowId="<?php echo $data['borrow_id'];?>">
                                    <div>
                                        <h3 class="text-dark-grey"><?php echo $data['borrow_return_date'];?></h3>
                                    </div>
                                    <div>
                                        <h3 class="text-black"><?php echo $data['borrow_description'];?></h3>
                                        <span class="text-black-grey"><?php echo $data['borrowed_from'];?></span>
                                    </div>
                                    <div>
                                        <span class="text-red">You Borrowed</span>
                                        <h3 class="text-red"><?php echo "₹".$data['borrow_amount']; ?></h3>
                                    </div>
                                    <div>
                                        <i class="fa-solid fa-check text-green"></i>
                                        <i class="fa-solid fa-trash right text-red"></i>
                                    </div>
                                    
                                    
                                    <script>
                                        
                                            $('#borrowNotifictionList .fa-check').click(function(){
                                            
                                                
                                            var borrowId = $(this).parent().parent().attr('borrowId');
                                            console.log(borrowId);
                                            
                                            
                                            window.location.href = `sql/borrowsettled.php`+'?borrowSettleId='+borrowId;

                                            });

                                            $('#borrowNotifictionList .fa-trash').click(function(){
                                            
                                                
                                            var borrowDeleteId = $(this).parent().parent().attr('borrowId');
                                            console.log(borrowDeleteId);
                                            
                                            
                                            window.location.href = `sql/borrowDeletesettled.php`+'?borrowSettleDeleteId='+borrowDeleteId;

                                            });
                                        

                                    </script>
                                </div>
                            </li>
                            <?php }}}} ?>
                       </ul>
                    </div>
                    <div class="month" id="lentNotifictionList">
                        <h5 class="text-black">Lent</h5> 
                        <ul>
                            <?php
                                if(mysqli_num_rows($allLentQuery) > 0){
                                    while($data = mysqli_fetch_array($allLentQuery)){
                                        if($data['status'] != "settled"){
                                            if($data['lent_return_date'] < $currentDate){
                            ?>
                            <li>
                                <div class="splitDetails" lentId="<?php echo $data['lent_id'];?>">
                                    <div>
                                        <h3 class="text-dark-grey"><?php echo $data['lent_return_date'];?></h3>
                                    </div>
                                    <div>
                                        <h3 class="text-black"><?php echo $data['lent_description'];?></h3>
                                        <span class="text-black-grey"><?php echo $data['lent_from'];?></span>
                                    </div>
                                    <div>
                                        <span class="text-green">You Lent</span>
                                        <h3 class="text-green"><?php echo "₹".$data['lent_amount']; ?></h3>
                                    </div>
                                    <div>
                                        <i class="fa-solid fa-check text-green"></i>
                                        <i class="fa-solid fa-trash right text-red"></i>
                                    </div>

                                    <script>
                                        
                                        $('#lentNotifictionList .fa-check').click(function(){
                                        
                                            
                                        var lentId = $(this).parent().parent().attr('lentId');
                                        console.log(lentId);
                                        
                                        
                                        window.location.href = `sql/lentsettled.php`+'?lentSettleId='+lentId;

                                        });


                                        
                                        $('#lentNotifictionList .fa-trash').click(function(){
                                            
                                                
                                            var lentDeleteId = $(this).parent().parent().attr('lentId');
                                            console.log(lentDeleteId);
                                            
                                            
                                            window.location.href = `sql/lentDeletesettled.php`+'?lentSettleDeleteId='+lentDeleteId;

                                            });
                                    

                                    </script>
                                </div>
                            </li>
                            <?php }}}} ?>
                       </ul>
                    </div>
                    <div class="month" id="investmentNotifictionList">
                        <h5 class="text-black">Investment</h5> 
                        <ul>
                            <?php
                                if(mysqli_num_rows($allInvestementQuery) > 0){
                                    while($data = mysqli_fetch_array($allInvestementQuery)){
                                        
                                        if($data['investment_maturity'] < $currentDate){
                            ?>
                            <li>
                                <div class="splitDetails" investmentId="<?php echo $data['investment_id'];?>">
                                    <div>
                                        <h3 class="text-dark-grey"><?php echo $data['investment_maturity'];?></h3>
                                    </div>
                                    <div>
                                        <h3 class="text-black"><?php echo $data['investment_description'];?></h3>
                                        
                                    </div>
                                    <div>
                                        <span class="text-blue">You Invested</span>
                                        <h3 class="text-blue"><?php echo "₹".$data['investment_amount']; ?></h3>
                                    </div>
                                    <div>
                                        
                                        <i class="fa-solid fa-trash right text-red"></i>
                                    </div>

                                    <script>
                                        
                                        $('#investmentNotifictionList .fa-check').click(function(){
                                        
                                            
                                        var investmentId = $(this).parent().parent().attr('investmentId');
                                        console.log(investmentId);
                                        
                                        
                                        window.location.href = `sql/investmentsettled.php`+'?investmentSettleId='+investmentId;

                                        });


                                        
                                        $('#lentNotifictionList .fa-trash').click(function(){
                                            
                                                
                                            var lentDeleteId = $(this).parent().parent().attr('lentId');
                                            console.log(lentDeleteId);
                                            
                                            
                                            window.location.href = `sql/lentDeletesettled.php`+'?lentSettleDeleteId='+lentDeleteId;

                                            });
                                    

                                    </script>
                                </div>
                            </li>
                            <?php }}} ?>
                       </ul>
                    </div>
                </div>
            </div>
    </div>
</div>

<!-- 

<script>
$(document).ready(function(){

    $('#borrowNotifictionList .fa-check').click(function(){
       var borrowId = $(this).parent().parent().attr('borrowId');
       console.log(borrowId);
       //$.post("sql/borrowsettled.php", { borrowSettleId: borrowId} );
       window.location.href = 'sql/borrowsettled.php?borrowSettleId=';
    });


});

</script> -->