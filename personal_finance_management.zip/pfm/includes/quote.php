<?php include_once("sql/connection.php"); ?>
<?php
    $select = "SELECT * FROM `quotes`";
    $query = mysqli_query($con,$select);
    $max = mysqli_num_rows($query);
    $min = 1;
    $random = mt_rand($min,$max);

    //print_r($arr); 
?>
<div class="conatiner-fluid">
    <div class="container quote">
        <div>
            <q>
                <?php
                while($data = mysqli_fetch_array($query)){
                    if($data['q_id'] == $random){
                        echo $data['quotes'];}}
            ?>
            </q>
        </div>
        <span>
            <?php
        while($data = mysqli_fetch_array($query)){
                    if($data['q_id'] === $random){
                        echo $data['author'];}}
        ?>
        </span>
    </div>
</div>