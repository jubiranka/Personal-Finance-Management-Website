<?php  include_once("sql/connection.php"); ?>
<div class="container-fluid">
    <div class="container addTable">
        <div class="side-list">
            <ul>
                <li><a href="#" class="addDebitBtn">Debit</a></li>
                <li><a href="#" class="addCreditBtn">Credit</a></li>
                <li><a href="#" class="addInvestmentBtn">Investements</a></li>
                <li><a href="#" class="addBorrowedBtn">Borrowed</a></li>
                <li><a href="#" class="addLendBtn">Lend</a></li>
                <!-- <li><a href="#" class="addFriendBtn">Friends</a></li> -->
                <li><a href="#" class="addSplitBtn">Split Expense</a></li>
            </ul>
        </div>

        <!-- side list menu for small width devices -->
        <div class="side-list-menu d-none">
            <i class="fa-solid fa-x right text-yellow"></i> 
            <ul>
                <li><a href="#" class="addDebitBtn">Debit</a></li>
                <li><a href="#" class="addCreditBtn">Credit</a></li>
                <li><a href="#" class="addInvestmentBtn">Investements</a></li>
                <li><a href="#" class="addBorrowedBtn">Borrowed</a></li>
                <li><a href="#" class="addLendBtn">Lend</a></li>
                <li><a href="#" class="addFriendBtn">Friends</a></li>
                <li><a href="#" class="addSplitBtn">Split Expense</a></li>
            </ul>
        </div>


        <div class="side-change">

            <!-- debit add form -->
            <div class="addForms" id="addDebitForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">

                    <form action="sql/addDebit.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Debit Source" name="debitDescription"></textarea>
                        <input type="date" name="debit-date">
                        <input type="number" name="debit-amount">
                        <span class="text-dark-grey"><label for="payer">Category</label></span>
                        <select id="payer" name="payer">
                          <option value="Lent">Lent</option>
                          <option value="Investement">Investement</option>
                          <option value="Miscellaneous">Miscellaneous</option>
                        </select>
                        <button class="btn" name="debit-submit">ADD</button>
                    </form>
                </div>
            </div>



            <!-- add credit form -->
            <div class="d-none addForms" id="addCreditForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">
                    <form action="sql/addCredit.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Credit Source" name="creditDescription"></textarea>
                        <input type="date" name="credit-date">
                        <input type="number" name="credit-amount">
                        <span class="text-dark-grey"><label for="payer">Category</label></span>
                        <select id="payer" name="payer">
                          <option value="Borrowed">Borrowed</option>
                          <option value="Gift">Gift</option>
                          <option value="Miscellaneous">Miscellaneous</option>
                        </select>
                        <button class="btn" name="credit-submit">ADD</button>
                    </form>
                </div>
            </div>



            <!-- add investment form -->
            <div class="d-none addForms" id="addInvestmentForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">
                    <form action="sql/addInvestment.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Investment Source" name="investmentDescription"></textarea>
                        <input type="date" name="investment-date">
                        <input type="number" name="investment-amount">
                        <span class="text-dark-grey"><label for="investmentCategory">Category</label></span>
                        <select id="investmentCategory" name="investCategory">
                          <option value="FixedDeposits">Fixed Deposits</option>
                          <option value="termDeposits">Term Deposits</option>
                          <option value="PPF">PPF</option>
                          <option value="Stocks">Stocks</option>
                          <option value="Other">Other</option>
                        </select>
                        <div id="aboutInvestment">
                            <span class="text-dark-grey" id="ppfAbout">
                                <ul>
                                    <li>
                                    The Public Provident Fund (PPF) scheme is a very popular long-term savings scheme in India because of its combination of tax savings, returns, and safety
                                    </li>
                                    <li>
                                    The PPF scheme offers an attractive rate of interest and no tax is required to be paid on the returns that are generated from the interest rates
                                    </li>
                                    <li>
                                        Tenure of PPF is 15 years, which can be renewed in block of five years
                                    </li>
                                    <li>
                                        Investment amount ranges between ₹500 and ₹1.5 lakh per annum
                                    </li>
                                    <li>
                                        Interest Rate 7.1%
                                    </li>
                                    <li>
                                    The PPF interest rate is set every year by the ministry of finance and is paid each year on 31st March
                                    </li>
                                </ul>
                            </span>
                            <span class="text-dark-grey" id="termAbout">
                                <ul>
                                    <li>
                                    A term deposit is a type of deposit account held at a financial institution where money is locked up for some set period of time.
                                    </li>
                                    <li>
                                    Interest rates on term deposits are typically fixed based on the investment tenure, which means your investment is not subjected to market fluctuations.
                                    </li>
                                    <li>
                                    You can choose your preferred investment tenure, which could be anywhere from one to ten years. Remember that longer tenures translate to higher interest rates.
                                    </li>
                                    <li>
                                    Per the Income Tax Act of India, you have to pay a tax deducted at source (TDS) on the interest earned on the deposit.
                                    </li>
                                </ul>
                            </span>
                            <span class="text-dark-grey" id="fdAbout">
                                <ul>
                                    <li>
                                    A fixed deposit, also known as an FD, is an investment instrument offered by banks, as well as non-banking financial companies (NBFC) to their customers to help them save money.
                                    </li>
                                    <li>
                                    you can invest a sizeable amount of money at a predetermined rate of interest for a fixed period.
                                    </li>
                                    <li>
                                    You can choose a fixed deposit for a period ranging from minimum 7-14 days to maximum 10 years.
                                    </li>
                                    <li>
                                    The interest you earn is either paid at maturity or on periodic basis depending on your choice.
                                    </li>
                                    <li>
                                    You are not allowed to withdraw the money before the maturity. If you want to, you have to pay a penalty.
                                    </li>
                                </ul>
                            </span>
                        </div>
                        <input type="text" name="investment-interest" placeholder="Interest Rate" > </br>
                        <div id="variantInterestOpt">
                            <span class="text-dark-grey"><label for="variant">Variant of Interest</label></span></br>
                            <input type="radio" id="cumulative" name="variantInterest" value="cumulative">
                            <label for="cumulative" class="text-dark-grey">Cumulative</label>
                            <input type="radio" id="noncumulative" name="variantInterest" value="noncumulative">
                            <label for="noncumulative" class="text-dark-grey">Non-Cumulative</label><br>
                        </div> 
                        
                        
                        <div class="maturityInvestmentDiv">
                            <label for="" class="text-dark-grey">Investment Maturity</label>                      
                            <input type="date" name="investment-maturity">

                        </div>
                        <button class="btn" name="investment-submit">ADD</button>
                    </form>
                </div>
            </div>


            <!-- add borrow form -->
            <div class="d-none addForms" id="addBorrowedForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">
                    <form action="sql/addBorrow.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Borrowed Source" name="borrowedDescription"></textarea>
                        <div class="formInputFlex">
                            <div>
                                <span class="text-dark-grey">Date Of Borrowing</span>
                                <input type="date" name="borrowed-date">
                            </div>
                            <div>
                                <span class="text-dark-grey">Date Of Returning</span>
                                <input type="date" name="borrowed-return-date">
                            </div>
                            <div>
                                <span class="text-dark-grey">Borrowing Amount</span>
                                <input type="number" name="borrowed-amount">
                            </div>
                            <div>
                                <span class="text-dark-grey"><label for="borrow">From</label></span>
                                <input type="text" name="borrow" id="">
                            </div>
                        </div>
                        <button class="btn" name="borrowed-submit">ADD</button>
                    </form>
                </div>
            </div>




            <!-- add lend form -->
            <div class="d-none addForms" id="addLendForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">
                    <form action="sql/addLend.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Lend Source" name="lendDescription"></textarea>
                        <div class="formInputFlex">
                            <div>
                                <span class="text-dark-grey">Date Of Lending</span>
                                <input type="date" name="lend-date">
                            </div>
                            <div>
                                <span class="text-dark-grey">Date Of Returning</span>
                                <input type="date" name="lend-return-date">
                            </div>
                            <div>
                                <span class="text-dark-grey">Lending Amount</span>
                                <input type="number" name="lend-amount">
                            </div>
                            <div>
                                <span class="text-dark-grey"><label for="lendTo">To</label></span>
                                <input type="text" name="lendTo" id="">
                            </div>
                        </div>                        
                        <button class="btn" name="lend-submit">ADD</button>
                    </form>
                </div>
            </div>




            <!-- add friend window -->
            <!-- <div class="d-none" id="friends">
                <div class="friends-nav">
                    <div class="menuAndSearch">
                         menu for media query -->
                        <!-- <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div> -->

                        <!-- search bar -->
                        <!-- <div class="search">
                            <input type="text" class="search__input" placeholder="Find Friends">
                            <div class="search__icon">
                                <ion-icon name="search"></ion-icon>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listOfFriends">
                    <h4 class="text-black">All</h4>
                    <ul> -->
                        <?php
                            // $select = "SELECT * FROM `users`";
                            // $row = mysqli_query($con,$select);
                            // if(mysqli_num_rows($row) > 0){
                            //     while($data = mysqli_fetch_array($row)){
                        ?>
                        <!-- <li>
                            <div class="splitDetails">
                                <div>
                                    <img src="assets/images/profile_photo/<?
                                    //php echo $data['profile_photo'];?>" alt=""> -->
                                <!-- </div>
                                <div>
                                    <h3 class="text-black"><?php //echo $data['name'];?></h3>
                                    <span><?php //echo $data['username'];?></span>
                                </div>
                                <div>
                                    <a href="" > -->
                                        <!-- <button class="btn bg-yellow text-white" name="requestBtn" friendusername="<?php //echo $data['username'];?>" friendname="<?php //echo $data['name'];?>">Request</button>
                                    </a>
                                </div>
                            </div> -->
                        <!-- </li>
                        <?php // } }       ?>
                    </ul>
                </div>
            </div> -->






            <!-- add split expense form -->
            <div class="d-none addForms" id="splitExpenseForm">
                <div class="menuAndSearch">
                        <!-- menu for media query -->
                        <div class="mediaMenu">
                            <i class="fa-solid fa-bars"></i>
                        </div>
                </div>
                <div class="form-div">

                    <form action="sql/addSplit.php" method="post">
                        <textarea  id="" cols="" rows="5" placeholder="Enter Expense Description" name="splitExpenseDescription"></textarea>
                        <input type="date" name="splitExpense-date">
                        <input type="number" name="splitExpense-amount">
                        <br>
                        <span class="text-dark-grey"><label for="payer">Paid By</label></span></br>
                        
                        
                            <input type="radio" id="you" name="paidBy" value="you">
                            <label for="you" class="text-dark-grey">You</label>
                            <input type="radio" id="others" name="paidBy" value="others">
                            <label for="others" class="text-dark-grey">Others</label><br>

                            <!-- if clicked on others then this would appear -->
                            <input type="text" id="payee" name="othersPayee">

                        <!-- split between number decision -->
                        <span class="text-dark-grey"><label for="splitingParties">Split Between</label></span>
                        <input type="text" name="splitBtw" id="splitBtw">


                        <!-- split between name loop -->
                        <div id="splitPeopleDiv"> 
                            <div class="splitPartyDiv" id="splitPartyDiv<?php echo $_SESSION['username'];?>">
                                <input type='text' class='splitPartyName' name='splitPartyName' placeholder="<?php echo $_SESSION['username'];?>" disabled>
                                <input type='number' name='splitPartyShare'>
                            </div>
                            <script>
                                $('#splitBtw').on('keyup', function () {
                                    var splitVal = $('#splitBtw').val();
                                    $('#splitPartyDiv<?php echo $_SESSION['username'];?>').siblings().remove();
                                    for (let i = 1; i < splitVal; i++) {
                                        $('#splitPeopleDiv').append("<div class='splitPartyDiv' name='splitPartyDiv'><input type='text' name='splitPartyName"+i+"' class='splitPartyName'><input type='number' name='splitPartyShare'></div>");
                                        
                                    }
                                });
                            </script>
                        </div>

                        <!-- error message showing div -->
                        <div id="divisionErr">
                            <span></span>
                        </div>

                        <!-- how to split code that is equal, amount , portions etc -->
                        <div id="splitDivisionDiv">
                            <div>
                                <i class="fa-sharp fa-solid fa-equals"></i>
                            </div>
                            <!-- <div>
                                <i class="fa-sharp fa-solid fa-percent"></i>
                            </div>
                            <div>
                                <i class="fa-sharp fa-solid fa-chart-simple"></i>
                            </div>
                            <div>
                                <i class="fa-sharp fa-solid fa-indian-rupee-sign"></i>
                            </div> -->
                        </div>
                                                                           
                        <button class="btn" name="split-submit">Split</button>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>

