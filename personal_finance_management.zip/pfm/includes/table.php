<?php
    error_reporting(0);//because two session start were in the code
    include_once("sql/userConnection.php");

    $allDebit = "SELECT * FROM `debit` ORDER BY `debit_date` DESC";
    $allCredit = "SELECT * FROM `credit` ORDER BY `credit_date` DESC";
    $allInvestment = "SELECT * FROM `investment` ORDER BY `investment_date` DESC";
    $allBorrow = "SELECT * FROM `borrow` ORDER BY `borrow_date` DESC";
    $allLent = "SELECT * FROM `lent` ORDER BY `lent_date` DESC";
    $allDebitQuery = mysqli_query($conDb,$allDebit);
    $allCreditQuery = mysqli_query($conDb,$allCredit);
    $allInvestmentQuery = mysqli_query($conDb,$allInvestment);
    $allBorrowQuery = mysqli_query($conDb,$allBorrow);
    $allLentQuery = mysqli_query($conDb,$allLent);

?>



<div class="container-fluid">
    <div class="container table">
        <div class="side-list">
            <ul>
                <li><a href="#" class="debitBtn">Debit</a></li>
                <li><a href="#" class="creditBtn">Credit</a></li>
                <li><a href="#" class="investmentBtn">Investments</a></li>
                <li><a href="#" class="borrowedBtn">Borrowed</a></li>
                <li><a href="#" class="lendBtn">Lend</a></li>
                <!-- <li><a href="#" class="reportBtn">Report</a></li> -->
            </ul>
        </div>

        <!-- side list menu for small width devices -->
        <div class="side-list-menu d-none">
            <i class="fa-solid fa-x right text-yellow"></i> 
            <ul>
                <li><a href="#" class="debitBtn">Debit</a></li>
                <li><a href="#" class="creditBtn">Credit</a></li>
                <li><a href="#" class="savingBtn">Savings</a></li>
                <li><a href="#" class="investmentBtn">Investements</a></li>
                <li><a href="#" class="borrowedBtn">Borrowed</a></li>
                <li><a href="#" class="lendBtn">Lend</a></li>
            </ul>
        </div>


        <div class="side-change">


            <!-- right side debit column -->
            <div id="debit" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search..." name="debitSearch">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                <!-- details table -->
                <div class="category_table">                
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Debit Source</th>
                            <th>Amount</th>
                            <!-- <th>Change</th> -->
                        </tr>
                        <?php
                                if(mysqli_num_rows($allDebitQuery) > 0){
                                    while($data = mysqli_fetch_array($allDebitQuery)){
                        ?>
                        <tr class="allDebitList">
                            <td><?php echo $data['debit_date'];?></td>
                            <td><?php echo $data['debit_description'];?></td>
                            <td><?php echo "₹ ".$data['debit_amount'];?></td>
                            <!-- <td>
                                <i class="fa-solid fa-pen left text-yellow"></i>
                                <i class="fa-solid fa-trash right text-red"></i>
                            </td> -->
                        </tr>
                        <?php }}?>
                        
                    </table>
                </div>
                <a href="editChanges.php">
                    <button class="btn" id="addEditChangeButton" name="addEditChangeButton">SAVE</button>
                </a>
                <a href="add.php">
                    <button class="btn" id="addDebitButton" name="addDebitButton">ADD</button>
                </a>
            </div>


            <!-- right side credit column -->
            <div id="credit" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search...">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                <div class="category_table">                
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Credit Source</th>
                            <th>Amount</th>
                            <!-- <th>Change</th> -->
                        </tr>
                        <?php
                                if(mysqli_num_rows($allCreditQuery) > 0){
                                    while($data = mysqli_fetch_array($allCreditQuery)){
                        ?>
                        <tr>
                            <td><?php echo $data['credit_date'];?></td>
                            <td><?php echo $data['credit_description'];?></td>
                            <td><?php echo "₹ ".$data['credit_amount'];?></td>
                            <!-- <td>
                                <i class="fa-solid fa-pen left text-yellow"></i>
                                <i class="fa-solid fa-trash right text-red"></i>
                            </td> -->
                        </tr>
                        <?php }}?>
                    </table>
                </div>
                <a href="add.php">
                    <button class="btn" id="addCreditButton" name="addCreditButton">ADD</button>
                </a>
            </div>




            <!-- right side investments column -->
            <div id="investments" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search...">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                <div class="category_table">                
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Investment Description</th>
                            <th>Amount</th>
                            <!-- <th>Change</th> -->
                        </tr>
                        <?php
                                if(mysqli_num_rows($allInvestmentQuery) > 0){
                                    while($data = mysqli_fetch_array($allInvestmentQuery)){
                        ?>
                        <tr>
                            <td><?php echo $data['investment_date'];?></td>
                            <td><?php echo $data['investment_description'];?></td>
                            <td><?php echo "₹ ".$data['investment_amount'];?></td>
                            <!-- <td>
                                <i class="fa-solid fa-pen left text-yellow"></i>
                                <i class="fa-solid fa-trash right text-red"></i>
                            </td> -->
                        </tr>
                        <?php 
                            }}
                        ?>
                    </table>
                </div>
                <a href="add.php">
                    <button class="btn" id="addInvestmentButton" name="addInvestmentButton">ADD</button>
                </a>
            </div>


            <!-- right side borrowed column -->
            <div id="borrowed" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search...">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                <div class="category_table">                
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Borrowing Description</th>
                            <th>Amount</th>
                            <th>Borrowed From</th>
                            <th>Due Date</th>
                            <!-- <th>Change</th> -->
                        </tr>
                        <?php
                                if(mysqli_num_rows($allBorrowQuery) > 0){
                                    while($data = mysqli_fetch_array($allBorrowQuery)){
                        ?>
                        <tr>
                            <td><?php echo $data['borrow_date'];?></td>
                            <td><?php echo $data['borrow_description'];?></td>
                            <td><?php echo "₹ ".$data['borrow_amount'];?></td>
                            <td><?php echo $data['borrowed_from'];?></td>
                            <td><?php echo $data['borrow_return_date'];?></td>
                            <!-- <td>
                                <i class="fa-solid fa-pen left text-yellow"></i>
                                <i class="fa-solid fa-trash right text-red"></i>
                            </td> -->
                        </tr>
                        <?php }}?>
                    </table>
                </div>
                <a href="add.php">
                    <button class="btn" id="addBorrowedButton" name="addBorrowedButton">ADD</button>
                </a>
            </div>


            <!-- right side lend column -->
            <div id="lend" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search...">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                <div class="category_table">                
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Lending Source</th>
                            <th>Amount</th>
                            <th>Lent To</th>
                            <th>Due Date</th>
                            <!-- <th>Change</th> -->
                        </tr>
                        <?php
                                if(mysqli_num_rows($allLentQuery) > 0){
                                    while($data = mysqli_fetch_array($allLentQuery)){
                        ?>
                        <tr>
                            <td><?php echo $data['lent_date'];?></td>
                            <td><?php echo $data['lent_description'];?></td>
                            <td><?php echo "₹ ".$data['lent_amount'];?></td>
                            <td><?php echo $data['lent_from'];?></td>
                            <td><?php echo $data['lent_return_date'];?></td>
                            <!-- <td>
                                <i class="fa-solid fa-pen left text-yellow"></i>
                                <i class="fa-solid fa-trash right text-red"></i>
                            </td> -->
                        </tr>
                        <?php }}?>
                    </table>
                </div>
                <a href="add.php">
                    <button class="btn" id="addLendButton" name="addLendButton">ADD</button>
                </a>
            </div>





            <div id="report" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->
                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>

                    <!-- search bar -->
                    <div class="search">
                        <input type="text" class="search__input" placeholder="Search...">
                        <div class="search__icon">
                            <ion-icon name="search"></ion-icon>
                        </div>
                    </div>
                </div>
                
                <a href="add.php">
                    <button class="btn" id="addLendButton" name="addLendButton">ADD</button>
                </a>
            </div>


            
        </div>
    </div>
</div>







<script>

$('[name="debitSearch"]').on('keypress keydown keyup',function(){
    var debitSearchValue = $(this).val();
    console.log(debitSearchValue);
    <?php 
        //$_SESSION['debitSearchValue'] = "<script> document.write(debitSearchValue) </script>";
    ?>
    $('.allDebitList').hide();
    $('.searchDebitList').show();
});


</script>