<div class="container-fluid">
    <div class="container table">
        <div class="side-list">
            <ul>
                <li><a href="#" class="nameBtn">Name</a></li>
                <li><a href="#" class="usernameBtn">Username</a></li>
                <li><a href="#" class="passwordBtn">Password</a></li>
                <li><a href="#" class="deleteBtn">Delete</a></li>
                <li><a href="#" class="appearanceBtn">Appearance</a></li>
                <li><a href="#" class="logoutBtn">Logout</a></li>
            </ul>
        </div>

        <!-- side list menu for small width devices -->
        <div class="side-list-menu d-none">
            <i class="fa-solid fa-x right text-yellow"></i> 
            <ul>
                <li><a href="#" class="nameBtn">Name</a></li>
                <li><a href="#" class="usernameBtn">Username</a></li>
                <li><a href="#" class="passwordBtn">Password</a></li>
                <li><a href="#" class="blockBtn">Block</a></li>
                <li><a href="#" class="deleteBtn">Delete</a></li>
                <li><a href="#" class="appearanceBtn">Appearance</a></li>
                <li><a href="#" class="logoutBtn">Logout</a></li>
            </ul>
        </div>


        <div class="side-change">


            <!-- right side settingName column -->

            <div id="settingName" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >                
                    <div>
                        <h4 class="text-black">Name</h4>
                        <span class="text-dark-grey"><?php echo $_SESSION['name'];?></span>
                            <button class="btn d-block bg-yellow text-white" id="changeNameBtn">Change</button>
                    </div>
                    <div class="d-none">
                        <form action="sql/settingChangeName.php" method="post">
                            <label for="newName" class="text-dark-grey">Enter New Name</label>
                            <input type="text" id="newName" name="newName">
                                <button class="btn d-block bg-yellow text-white" id="" name="saveName">Save</button>
                        </form>
                    </div>
                </div>
            </div>



            <!-- right side settingUsername column -->
            <div id="settingUsername" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >                
                    <div>
                        <h4 class="text-black">Username</h4>
                        <span class="text-dark-grey"><?php echo $_SESSION['username'];?></span>
                            <button class="btn d-block bg-yellow text-white" id="changeUsernameBtn">Change</button>
                    </div>
                    <div class="d-none">
                        <form action="sql/settingChangeusername.php" method="post">
                            <label for="newUsername" class="text-dark-grey">Enter New Username</label>
                            <input type="text" id="newUsername" name="newUsername">
                                <button class="btn d-block bg-yellow text-white" id="" name="saveUsername">Save</button>
                        </form>
                    </div>
                </div>
            </div>


            
            <!-- right side settingPassword column -->
            <div id="settingPassword" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >
                    <form action="" method="post">                 
                    <!-- old password enter from user -->
                        <label for="oldPassword" class="text-dark-grey">Enter Your Old Password</label>
                        <input type="text" id="oldPassword" name="oldPassword">
                        <span class="text-red d-none" >Password Doesn't Match</span>


                    <!--new password from user  -->
                        <label for="newPassword" class="text-dark-grey">Enter New Password</label>
                        <input type="text" id="newPassword" name="newPassword">
                        <span class="text-red d-none" >A password must have 8 characters , 1 capital letter , 1 number and 1 special character</span>

                        
                    <!--new password from user check -->
                        <label for="newPasswordVerify" class="text-dark-grey">Verify Password</label>
                        <input type="text" id="newPasswordVerify" name="newPasswordVerify">
                        <span class="text-red d-none" >Password Doesn't Match</span>
                        
                        
                        <button class="btn d-block bg-yellow text-white" id="" name="savePassword">Save</button>
                    </form>
                </div>
            </div>


            <!-- right side deleting account setting column -->
            <div id="settingDelete" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >  
                    <div class="boxAction">
                        <h4 class="text-black">Are You Sure You Want To Delete Your Account?</h4>
                        <form action="sql/deleteAccount.php" method="post">
                            <button class="btn d-block bg-yellow text-white" id="deleteAccount" name="deleteAccount">Delete</button>
                        </form>
                    </div>
                </div>
            </div>


             <!-- right side app apperane account setting column -->
             <div id="settingApperance" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >  
                    <div class="boxAction">
                        <h4 class="text-black">Dark Mode</h4>
                        <form action="" method="">
                            <div>
                                <input type="checkbox" class="checkbox" id="checkbox">
                                <label for="checkbox" class="label">
                                    <i class="fas fa-moon"></i>
                                    <i class='fas fa-sun'></i>
                                    <div class='ball'>
                                </label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- right side logging out account setting column -->
            <div id="settingLogout" class="commonDC">
                <div class="menuAndSearch">
                    <!-- menu for media query -->

                    <div class="mediaMenu">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <!-- details table -->
                <div class="changeData" >  
                    <div class="boxAction">
                        <h4 class="text-black">Are You Sure You Want To Logout Your Account?</h4>
                        <form action="sql/logoutAccount.php" method="post">
                            <button class="btn d-block bg-yellow text-white" id="logoutAccount" name="logoutAccount">Logout</button>
                        </form>
                    </div>
                </div>
            </div>



        </div>
    </div>
</div>



<!-- setting old password input by user -->




<script>
var $actualPassword = "<?php echo $_SESSION['password'];?>";
$('#oldPassword').on('keypress keydown keyup',function(){
        $oldPasswordVal = $('#oldPassword').val();
        if (!$(this).val().match($actualPassword)) {
         // there is a mismatch, hence show the error message
            $('#oldPassword').next().removeClass('d-none');
        }
        else{
           // else, do not display message
           $('#oldPassword').next().addClass('d-none');
          }
});






const checkbox = document.getElementById('checkbox');

checkbox.addEventListener('change', ()=>{
    console.log("fegvcbdhnjxm");
    if (document.body.style.getPropertyValue('--black') === '#D9D9D9' && document.body.style.getPropertyValue('--black-grey') === '#EBEBEB' && document.body.style.getPropertyValue('--some-white') === '#585657' && document.body.style.getPropertyValue('--dark-grey') === '#f1f1f1' && document.body.style.getPropertyValue('--dark-white') === '#626060' && document.body.style.getPropertyValue('--light-grey') === '#626060') {

      document.body.style.setProperty('--dark-white', '#f1f1f1');
      document.body.style.setProperty('--black-grey' , '#585657');
      document.body.style.setProperty('--some-white' , '#EBEBEB');
      document.body.style.setProperty('--dark-grey' , '#626060');
      document.body.style.setProperty('--black' , '#383838');
      document.body.style.setProperty('--light-grey' , '#D9D9D9');

    } else {
        document.body.style.setProperty('--black' , '#D9D9D9'); 
        document.body.style.setProperty('--black-grey' , '#EBEBEB');  document.body.style.setProperty('--some-white' , '#585657');  document.body.style.setProperty('--dark-grey' , '#f1f1f1');  document.body.style.setProperty('--dark-white' , '#626060');
        document.body.style.setProperty('--light-grey' , '#626060');
    }
})



// const checkbox = document.getElementById('checkbox');

// checkbox.addEventListener('change', ()=>{
//     let ele = document.querySelector(':root');
//     let cs = getComputedStyle(ele);
//     if(cs.getPropertyValue('--dark-white') !== '#626060' && cs.getPropertyValue('--dark-grey') !== '#f1f1f1') {
//       item.style.setProperty('--customColor', 'blue')
//    }
//   document.body.classList.toggle('dark');
// })

</script>



