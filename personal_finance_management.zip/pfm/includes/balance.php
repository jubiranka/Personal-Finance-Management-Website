<?php 
    error_reporting(0);//because two session start were in the code
    include_once("sql/userConnection.php"); ?>
<?php
    $year = date("Y");
    $month = date("m");

    
    $creditSelect = "SELECT * FROM `credit` WHERE YEAR(`credit_date`) = $year AND MONTH(`credit_date`) = $month";

    $rowsCredit = mysqli_query($conDb,$creditSelect);
    $creditTotalPerMonth = 0;
    if(mysqli_num_rows($rowsCredit) > 0){
        while($data = mysqli_fetch_array($rowsCredit)){
            $creditTotalPerMonth += (int)$data['credit_amount'];
        }
    }
    else{
        $creditTotalPerMonth = 0;
    }


    
    $debitSelect = "SELECT * FROM `debit` WHERE YEAR(`debit_date`) = $year AND MONTH(`debit_date`) = $month";

    $rowsDebit = mysqli_query($conDb,$debitSelect);
    $debitTotalPerMonth = 0;
    if(mysqli_num_rows($rowsDebit) > 0){
        while($data = mysqli_fetch_array($rowsDebit)){
            $debitTotalPerMonth += (int)$data['debit_amount'];
        }
    }
    else{
        $debitTotalPerMonth = 0;
    }


    $debitSelectAll = "SELECT * FROM `debit`";
    $creditSelectAll = "SELECT * FROM `credit`";
    $rowsDebitAll = mysqli_query($conDb,$debitSelect);
    $rowsCreditAll = mysqli_query($conDb,$creditSelect);
    $debitTotal = 0;
    $creditTotal = 0;
    if(mysqli_num_rows($rowsDebitAll) > 0){
        while($data = mysqli_fetch_array($rowsDebitAll)){
            $debitTotal += (int)$data['debit_amount'];
        }
    }
    else{
        $debitTotal = 0;
    }

    if(mysqli_num_rows($rowsCreditAll) > 0){
        while($data = mysqli_fetch_array($rowsCreditAll)){
            $creditTotal += (int)$data['credit_amount'];
        }
    }
    else{
        $creditTotal = 0;
    }



$monthFullNo = (int)$month;

    switch ($monthFullNo) {
        case 01:
            $monthFull = 'January';
            break;
        case 02:
            $monthFull = 'February';
            break;        
        case 03:
            $monthFull = 'March';
            break;
        case 04:
            $monthFull = 'April';
            break;
        case 05:
            $monthFull = 'May';
            break;
        case 06:
            $monthFull = 'June';
            break;
        case 07:
            $monthFull = 'July';
            break;
        case 8:
            $monthFull = 'August';
            break;
        case 9:
            $monthFull = 'September';
            break;
        case 10:
            $monthFull = 'October';
            break;
        case 11:
            $monthFull = 'November';
            break;
        case 12:
            $monthFull = 'December';
            break;
        default:
            $monthFull = 'Not a valid month!';
        
            break;
        }
?>
<div class="container-fluid">
    <div class="container balance">
        <div class="amounts">
            <h4 class="text-green">
            <?php echo "₹ ".$creditTotalPerMonth; ?>
            </h4>
            <span>
            <?php echo $monthFull." Credit"; ?>
            </span>
        </div>
        <div class="amounts">
            <h4 class="text-yellow">
            <?php echo "₹ ".($creditTotal - $debitTotal); ?>
            </h4>
            <span>
                Balance
            </span>
        </div>
        <div class="amounts">
            <h4 class="text-red">
            <?php echo "₹ ".$debitTotalPerMonth; ?>
            </h4>
            <span>
            <?php echo $monthFull." Debit"; ?>
            </span>
        </div>
    </div>
</div>