<div class="container-fluid profile-menu">
    <div class="container menu">
        <ul>
            <li>
                <a href="home.php">
                <i class="fa-sharp fa-solid fa-house"></i>
                </a>
            </li>
            <li>
                <a href="message.php">
                    <i class="fa-sharp fa-solid fa-list"></i>
                </a>
            </li>
            <li>
                <a href="profile.php">
                    <i class="fa-solid fa-bell"></i>
                </a>
            </li>
            <li>
                <a href="add.php">
                    <i class="fa-solid fa-plus"></i>
                </a>
            </li>
            <li>
                <a href="settings.php">
                <i class="fa-solid fa-gear"></i>
                </a>
            </li>
        </ul>
    </div>
</div>