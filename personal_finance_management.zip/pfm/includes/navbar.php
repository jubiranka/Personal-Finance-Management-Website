<div class="container-fluid">
    <div class="container navbar">
        <div>
            <img src="assets/images/logoTrans.png" alt="pfm logo">
        </div>
        <div >
            <div>
                <h4>
                    Welcome
                </h4>
                <span>
                    <?php echo $_SESSION['username']; ?>
                </span>
            </div>
            <div>
                <img src="assets/images/profile_photo/<?php echo $_SESSION['profilePhoto']; ?>" alt="">
            </div>
        </div>
    </div>
</div>