<div class="container-fluid">
    <div class="container circle">
        <div class="circle-box">
            <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" name="expense">
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#D3D6DF" stroke-width="10" id="back"/>
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#F98012" stroke-width="10" id="front" />
            </svg>
            <span class="text-orange">Expenses</span>
        </div>
        <div class="circle-box">
            <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" name="savings">
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#D3D6DF" stroke-width="10" id="back"/>
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#3B67BD" stroke-width="10" id="front" />
            </svg>
            <span class="text-blue">Miscellaneous</span>
        </div>
        <div class="circle-box">
            <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" name="investments">
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#D3D6DF" stroke-width="10" id="back"/>
                <path d="M95 50C95 74.8528 74.8528 95 50 95C25.1472 95 5 74.8528 5 50C5 25.1472 25.1472 5 50 5C74.8528 5 95 25.1472 95 50Z" stroke="#88CA47" stroke-width="10" id="front" />
            </svg>
            <span class="text-green">Investments</span>
        </div>        
    </div>
</div>