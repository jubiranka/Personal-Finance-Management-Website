<div class="container-fluid" id="newUser">
    <div class="container">
        <form action="sql/newUserEntry.php" method="post" enctype="multipart/form-data">
                <fieldset>
                    <legend>Name</legend>
                    <input type="text" name="userName">
                    <span class="text-red d-none" >Enter a Valid Name</span>
                </fieldset>
                <fieldset>
                    <legend>Username</legend>
                    <input type="text" name="username">
                    <span class="text-red d-none" >Enter a Valid Name</span>
                </fieldset>
                <fieldset>
                    <legend>E-Mail</legend>
                    <input type="email" name="userEMail">
                    <span class="text-red d-none" >
                        Enter a Valid Username
                    </span>
                        <?php 
                            if(isset($_GET['userExists'])){
                                ?>
                                <script> alert("<?php echo $_GET['userExists'];?>")</script>
                                <?php
                            }
                        ?>
                    
                </fieldset>
                <fieldset>
                    <legend>Password</legend>
                    <input type="password" name="userPassword">
                    <span class="text-red d-none" >A password must have 8 characters , 1 capital letter , 1 number and 1 special character</span>
                </fieldset>
                <fieldset>
                    <legend>Contact No.</legend>
                    <input type="number" name="userContact">
                    <span class="text-red d-none" >Enter a Valid Conatct No.</span>
                </fieldset>
                <fieldset>
                    <legend>Date Of Birth</legend>
                    <input type="date" name="userDOB">
                </fieldset>
                <fieldset>
                    <legend>Profile Photo</legend>
                    <label for="profilePhoto">
                        <i class="fa-solid fa-camera-retro"></i>
                        <input type="file" name="profilePhotoAddress" accept="image/png, image/jpg, image/gif, image/jpeg"/>
                    </label>
                </fieldset>
                <div>
                    <button class="btn bg-yellow text-white" name="submitNewUser">Submit</button>
                </div>
        </form>
    </div>
</div>




