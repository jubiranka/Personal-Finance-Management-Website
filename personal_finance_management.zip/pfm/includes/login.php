<div class="container-fluid" id="login">
    <div class="login-form">
        <img src="assets/images/logo.png" alt="">
        <form action="sql/loginCheck.php" method="POST" autocomplete='off'>
                <input type="text" placeholder="ENTER YOUR USERNAME" name="username">
                <input type="password" placeholder="ENTER YOUR PASSWORD" name="password" autocomplete="on" required>
                <!-- <input type="checkbox" name="rememberMe" id=""> -->
                <!-- <label for="">REMEMBER ME</label> -->
                <a href="signUp.php">New User? Sign Up!</a>
                <button class="btn" name="login">Submit</button>
        </form>
    </div>
</div>