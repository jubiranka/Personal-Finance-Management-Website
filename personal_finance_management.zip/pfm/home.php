<?php  
    session_start();
    if (!$_SESSION['logIn']){ 
        header("Location:index.php");
        die();
    }
?>
<?php include_once("includes/header.php"); ?>
<?php include_once("includes/navbar.php"); ?>
<?php include_once("includes/balance.php"); ?>
<?php include_once("includes/circle.php"); ?>
<?php include_once("includes/quote.php"); ?>
<?php include_once("includes/menu.php"); ?>
<?php include_once("includes/footer.php"); ?>