<?php
if(!isset($_SESSION['idUser'])){
    header("location:index.php?unauthorisedAccess:YOU ARE NOT AUTHORISED");
    exit();
}
?>