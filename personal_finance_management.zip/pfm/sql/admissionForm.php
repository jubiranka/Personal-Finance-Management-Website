<?php
    include_once("connection.php"); 
    // $admissionInfo= "CREATE TABLE `admissionInfo` ( `admissionInfo_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `dob` DATE NOT NULL , `name` VARCHAR(400) NOT NULL , `image` VARCHAR(500) NOT NULL )";
    // mysqli_query($con , $admissionInfo);
    if(isset($_POST['submit'])){
        $name = $_POST['fName'];
        $dob = $_POST['dob'];
        $email = $_POST['email'];
        $image = $_FILES['image']['name'];
        $tempname = $_FILES['image']['tmp_name'];
        $dir = "../assets/images/$image";
        $insert = "INSERT INTO `admissionInfo`(`dob` , `name` , `image` ,`email`) VALUES ('$dob' , '$name' , '$image','$email')";
        mysqli_query($con,$insert);
        move_uploaded_file($tempname,$dir);
        // if(mysqli_query($con,$insert)){
        //     echo "inserted";
        // }
    }
    
    
    
?>