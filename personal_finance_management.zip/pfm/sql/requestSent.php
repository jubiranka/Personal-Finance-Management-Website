<?php
// session_start();
// include_once("../sql/connection.php");  
// if(isset($_POST['requestBtn'])){
//     $senderUsername = $_SESSION['username'];
//     $reciever_username = $_POST['friendusernamee'];


//     $insert = "INSERT INTO `friend_request`(`sender_username` , `reciever_username` , `request_status`) VALUES ('$senderUsername' , '$reciever_username' , 'requested')";
//     if(mysqli_query($con,$insert)){
//         header("Location:../add.php");
//     }
//     else{
//         header("Location:../add.php?requestingError:Error sending request");
//     }
// }


?>