<?php

include_once("../sql/userConnection.php");  ?>
<?php
$investmentDescription = $_POST['investmentDescription'];
$investmentDate = $_POST['investment-date'];
$investmentAmount = $_POST['investment-amount'];
$investCategory = $_POST['investCategory'];
$variantInterest = $_POST['variantInterest'];
$investmentmaturity = $_POST['investment-maturity'];
$investmentinterest = $_POST['investment-interest'];


if(isset($_POST['investment-submit'])){
    if($investCategory == "FixedDeposits"){
        $insert = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`,`investment_category`,`investment_maturity`,`investment_interest`,`interest_variant`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','$investCategory','$investmentmaturity','$investmentinterest','$variantInterest')";
        $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','FD')";
        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
            header("Location:../add.php");
        }
        else{
            header("Location:../add.php?unsuccessfullAddition=Could not add");
        }
    }
    else if($investCategory == "termDeposits"){
        $insert = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`,`investment_category`,`investment_maturity`,`investment_interest`,`interest_variant`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','$investCategory','$investmentmaturity','$investmentinterest','$variantInterest')";
        $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','Term Deposits')";
        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
            header("Location:../add.php");
        }
        else{
            header("Location:../add.php?unsuccessfullAddition=Could not add");
        }
    }
    else if($investCategory == "PPF"){
        $insert = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`,`investment_category`,`investment_maturity`,`investment_interest`,`interest_variant`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','$investCategory','$investmentmaturity','$investmentinterest','$variantInterest')";
        $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','PPF')";
        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
            header("Location:../add.php");
        }
        else{
            header("Location:../add.php?unsuccessfullAddition=Could not add");
        }
    }
    else if($investCategory == "Stocks"){
        $insert = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`,`investment_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','$investCategory')";
        $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','Stocks')";
        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
            header("Location:../add.php");
        }
        else{
            header("Location:../add.php?unsuccessfullAddition=Could not add");
        }
    }
    else{
        $insert = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`,`investment_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','$investCategory')";
        $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$investmentDate' , '$investmentDescription' , '$investmentAmount','Other Investment')";
        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
            header("Location:../add.php");
        }
        else{
            header("Location:../add.php?unsuccessfullAddition=Could not add");
        }
    }
}



?>