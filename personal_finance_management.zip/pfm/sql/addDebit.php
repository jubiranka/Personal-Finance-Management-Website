<?php

include_once("../sql/userConnection.php");  ?>
<?php
$debitDescription = $_POST['debitDescription'];
$debitDate = $_POST['debit-date'];
$debitAmount = $_POST['debit-amount'];
$payer = $_POST['payer'];


if(isset($_POST['debit-submit'])){
    $insert = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$debitDate' , '$debitDescription' , '$debitAmount','$payer')";

    if($_POST['payer'] === "Investment"){
        $insertI = "INSERT INTO `investment` (`investment_date`, `investment_description`, `investment_amount`) VALUES ('$debitDate' , '$debitDescription' , '$debitAmount')";
        mysqli_query($conDb,$insertI);
    }


    if(mysqli_query($conDb,$insert)){
        header("Location:../add.php");
    }
}



?>