<?php
session_start();
include_once("../sql/connection.php");  
echo "one"; 
if(isset($_POST['deleteAccount'])){
    $delete = "DELETE FROM users WHERE username = '". $_SESSION['username'] ."'";

    
    if(mysqli_query($con,$delete)){
        echo "two";
        header("Location:../index.php");
    }
    else{
        mysqli_error($con);
        echo "three";
        header('Location:../settings.php?accountNotDeleted:Account was not deleted');
    }
}

?>