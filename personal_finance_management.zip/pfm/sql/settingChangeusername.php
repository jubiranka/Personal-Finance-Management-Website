<?php 
session_start();
include_once("../sql/connection.php");  
$newUsername = $_POST['newUsername'];
$oldUsername = $_SESSION['username'];
if(isset($_POST['saveUsername'])){
     $update ="UPDATE users SET username = '".$newUsername."' WHERE username = '".$oldUsername."'";
    if(mysqli_query($con,$update)){
        $_SESSION['username'] = $newUsername;
        header('Location:../settings.php?usernameSuccessfullyUpdate:Username was updated');
    }
    else{
        header('Location:../settings.php?usernameNotUpdate:Username was not updated');
    }
}
?>