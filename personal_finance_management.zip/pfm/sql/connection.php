<?php
$username = "root";
$password = "";
$hostname = "localhost";
$db = "pfm";

$con = mysqli_connect($hostname , $username ,$password , $db);
?>