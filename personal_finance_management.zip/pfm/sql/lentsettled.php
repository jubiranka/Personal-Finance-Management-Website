<?php
include_once("../sql/userConnection.php"); 

$lentSettleId = $_GET['lentSettleId'];
echo $lentSettleId;



$insertlentSettled = "UPDATE `lent` SET `status` = 'settled' WHERE `lent_id` = '{$lentSettleId}'";
if(mysqli_query($conDb,$insertlentSettled)){
    header("Location:../profile.php");
}
else{
    header("Location:../add.php?unsuccessfullSettlement=Could not settle");
}

?>