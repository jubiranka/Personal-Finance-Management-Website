<?php

include_once("../sql/userConnection.php");  ?>
<?php
$borrowedDescription = $_POST['borrowedDescription'];
$borrowedDate = $_POST['borrowed-date'];
$borrowedReturnDate = $_POST['borrowed-return-date'];
$borrowedAmount = $_POST['borrowed-amount'];
$borrow = $_POST['borrow'];


if(isset($_POST['borrowed-submit'])){
    $insert = "INSERT INTO `borrow` (`borrow_date`, `borrow_description`, `borrow_amount`, `borrowed_from` , `borrow_return_date`) VALUES ('$borrowedDate' , '$borrowedDescription' , '$borrowedAmount','$borrow', '$borrowedReturnDate')";

    $insertI = "INSERT INTO `credit` (`credit_date`, `credit_description`, `credit_amount`, `credit_category`) VALUES ('$borrowedDate' , '$borrowedDescription' , '$borrowedAmount','Borrowed')";


    if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertI)){
        header("Location:../add.php");
    }
    else{
        header("Location:../add.php?unsuccessfullAddition=Could not add");
    }
}



?>