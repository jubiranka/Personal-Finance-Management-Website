<?php
session_start();
include_once("connection.php");
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if(isset($_POST['login'])){
        $select = "SELECT * FROM `users` WHERE `username` = '$username' and `password` = '$password'";
        $query = mysqli_query($con,$select);
        $rowCount = mysqli_num_rows($query);
        if($rowCount == 1){
            $data = mysqli_fetch_array($query);
            if($data['username']===$username && $data['password']===$password){
                header("location:../home.php");
                $_SESSION['databaseName']= $data['user_db'];
                $_SESSION['profilePhoto']= $data['profile_photo'];
                $_SESSION['name']= $data['name'];
                $_SESSION['username']= $data['username'];
                $_SESSION['password']= $data['password'];
                $_SESSION['id']= $data['user_id'];
                $_SESSION['logIn']= true;
            }
        }
        
        else{
            $_SESSION['logIn']= false;
            header("location:../index.php?errorNotification=ENTER VALID INFORMATION");
        }
        
    }
    else{
        die("no");
    }
    
    
    // if(isset($_POST['login'])){
    //     header("location:../admin/dashboard.php");
    //     echo($username);
    // echo($password);
    // }
    // else{
    //     mysqli_error($con);
    // }

?>