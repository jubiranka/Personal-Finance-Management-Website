<?php
    include_once("connection.php");
    $userName = $_POST['userName'];
    $username = $_POST['username'];
    $userEMail = $_POST['userEMail'];
    $userPassword = $_POST['userPassword'];
    $userContact = $_POST['userContact'];
    $userDOB = $_POST['userDOB'];
    $profilePhotoAddress = $_FILES['profilePhotoAddress']['name'];
    $profilePhotoAddressTemp = $_FILES['profilePhotoAddress']['tmp_name'];
    $dir = "../assets/images/profile_photo/$profilePhotoAddress";
    if(isset($_POST['submitNewUser'])){

        $select = "SELECT * FROM `users` WHERE `username` = '$username'";
        $query = mysqli_query($con,$select);
        $rowCount = mysqli_num_rows($query);
        if($rowCount == 0){
            $insert = "INSERT INTO `users`(`username` , `name` , `password` ,`email` , `phone` ,`dob` , `profile_photo` ,`user_db`) VALUES ('$username' , '$userName' , '$userPassword','$userEMail' , '$userContact' , '$userDOB','$profilePhotoAddress' ,'$username')";
            if(mysqli_query($con,$insert)){
                $usernamee = "root";//later change it to the actual username
                $passwordd = "";//assign the actual password
                $hostnamee = "localhost";
                $conn = mysqli_connect($hostnamee , $usernamee ,$passwordd);
                $create = "CREATE DATABASE `$username`";
                mysqli_query($conn,$create);



                $debitCreate = "CREATE TABLE `$username`.`debit` ( `debit_id` INT NOT NULL AUTO_INCREMENT , `debit_date` DATE NOT NULL , `debit_description` VARCHAR(600) NOT NULL , `debit_amount` DECIMAL(10,2) NOT NULL , `debit_remark` VARCHAR(1000) NOT NULL , `debit_category` VARCHAR(200) NOT NULL , PRIMARY KEY (`debit_id`))";
                mysqli_query($conn,$debitCreate);

                $creditCreate = "CREATE TABLE `$username`.`credit` ( `credit_id` INT NOT NULL AUTO_INCREMENT , `credit_date` DATE NOT NULL , `credit_description` VARCHAR(600) NOT NULL , `credit_amount` DECIMAL(10,2) NOT NULL , `credit_remark` VARCHAR(1000) NOT NULL , `credit_category` VARCHAR(200) NOT NULL , PRIMARY KEY (`credit_id`))";
                mysqli_query($conn,$creditCreate);


                $borrowCreate = "CREATE TABLE `$username`.`borrow` ( `borrow_id` INT NOT NULL AUTO_INCREMENT , `borrow_date` DATE NOT NULL , `status` VARCHAR(100), `borrow_amount` DECIMAL(10,2) NOT NULL , `borrow_return_date` DATE NOT NULL , `borrow_description` VARCHAR(600) NOT NULL , `borrowed_from` VARCHAR(200) NOT NULL , PRIMARY KEY (`borrow_id`))";
                mysqli_query($conn,$borrowCreate);


                $lentCreate ="CREATE TABLE `$username`.`lent` ( `lent_id` INT NOT NULL AUTO_INCREMENT , `lent_date` DATE NOT NULL , `lent_amount` DECIMAL(10,2) NOT NULL , `status` VARCHAR(100) , `lent_return_date` DATE NOT NULL , `lent_description` VARCHAR(600) NOT NULL , `lent_from` VARCHAR(200) NOT NULL , PRIMARY KEY (`lent_id`))";
                mysqli_query($conn,$lentCreate);



                $investmentCreate = "CREATE TABLE `$username`.`investment` ( `investment_id` INT NOT NULL AUTO_INCREMENT , `investment_date` DATE NOT NULL , `investment_description` VARCHAR(600) NOT NULL , `investment_amount` DECIMAL(10,2) NOT NULL , `investment_maturity` DATE NOT NULL, `investment_category` VARCHAR(100) NOT NULL ,`interest_variant` VARCHAR(100) NOT NULL ,`investment_interest` DECIMAL(10,0) NOT NULL , PRIMARY KEY (`investment_id`))"   ;
                mysqli_query($conn,$investmentCreate);         


                header("location:../index.php");
            }
            move_uploaded_file($profilePhotoAddressTemp,$dir);
        }
        else{
            header("location:../signUp.php?userExists=Username ALready Exists");
        }
    }



   

?>


<!-- 
CREATE TABLE `jubiranka77`.`debit` ( `debit_id` INT NOT NULL AUTO_INCREMENT , `debit_date` DATE NOT NULL , `debit_description` VARCHAR(600) NOT NULL , `debit_amount` DECIMAL(10,2) NOT NULL , `debit_remark` VARCHAR(1000) NOT NULL , `debit_category` VARCHAR(200) NOT NULL , PRIMARY KEY (`debit_id`))



CREATE TABLE `jubiranka77`.`borrow` ( `borrow_id` INT NOT NULL AUTO_INCREMENT , `borrow_date` DATE NOT NULL , `borrow_amount` DECIMAL(10,2) NOT NULL , `borrow_return_date` DATE NOT NULL , `borrow_description` VARCHAR(600) NOT NULL , `borrowed_from` VARCHAR(200) NOT NULL , PRIMARY KEY (`borrow_id`))


 CREATE TABLE `jubiranka77`.`lent` ( `lent_id` INT NOT NULL AUTO_INCREMENT , `lent_date` DATE NOT NULL , `lent_amount` DECIMAL(10,2) NOT NULL , `lent_return_date` DATE NOT NULL , `lent_description` VARCHAR(600) NOT NULL , `lent_from` VARCHAR(200) NOT NULL , PRIMARY KEY (`lent_id`))


CREATE TABLE `jubiranka77`.`investment` ( `investment_id` INT NOT NULL AUTO_INCREMENT , `investment_date` DATE NOT NULL , `investment_description` VARCHAR(600) NOT NULL , `investment_amount` DECIMAL(10,2) NOT NULL , `investment_remarks` VARCHAR(600) NOT NULL , PRIMARY KEY (`investment_id`))  -->