<?php
include_once("../sql/userConnection.php"); 

$lentSettleDeleteId = $_GET['lentSettleDeleteId'];
echo $lentSettleDeleteId;



$insertlentSettledDelete = "DELETE FROM `lent` WHERE `lent_id` ='{$lentSettleDeleteId}'";
if(mysqli_query($conDb,$insertlentSettledDelete)){
    header("Location:../profile.php");
}
else{
    header("Location:../add.php?unsuccessfullDeletion=Could not delete");
}

?>