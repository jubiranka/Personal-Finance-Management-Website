<?php

include_once("../sql/userConnection.php");  ?>
<?php
$lendDescription = $_POST['lendDescription'];
$lendDate = $_POST['lend-date'];
$lendReturnDate = $_POST['lend-return-date'];
$lendAmount = $_POST['lend-amount'];
$borrow = $_POST['borrow'];
$lendTo = $_POST['lendTo'];

if(isset($_POST['lend-submit'])){
    $insert = "INSERT INTO `lent` (`lent_date`, `lent_description`, `lent_amount`, `lent_from` , `lent_return_date`) VALUES ('$lendDate' , '$lendDescription' , '$lendAmount','$lendTo', '$lendReturnDate')";
    $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$lendDate' , '$lendDescription' , '$lendAmount','Lent')";
    if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertD)){
        header("Location:../add.php");
    }
    else{
        header("Location:../add.php?unsuccessfullAddition=Could not add");
    }
}



?>