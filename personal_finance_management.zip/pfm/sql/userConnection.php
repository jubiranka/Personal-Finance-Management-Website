<?php
session_start();
$usernameDb = "root";
$passwordDb = "";
$hostnameDb = "localhost";
$dbUc = $_SESSION['databaseName'];
$conDb = mysqli_connect($hostnameDb , $usernameDb ,$passwordDb , $dbUc);
?>