<?php 
session_start();
include_once("../sql/connection.php");  
$newName = $_POST['newName'];
$oldName = $_SESSION['name'];
if(isset($_POST['saveName'])){
     $update ="UPDATE users SET name = '".$newName."' WHERE name = '".$oldName."'";
    if(mysqli_query($con,$update)){
        $_SESSION['name'] = $newName;
        echo $_SESSION['name'];
        header('Location:../settings.php?nameSuccessfullyUpdate:Name was updated');
    }
    else{
        header('Location:../settings.php?nameNotUpdate:Name was not updated');
    }
}
?>