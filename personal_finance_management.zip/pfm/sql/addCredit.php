<?php

include_once("../sql/userConnection.php");  ?>
<?php
$creditDescription = $_POST['creditDescription'];
$creditDate = $_POST['credit-date'];
$creditAmount = $_POST['credit-amount'];
$payer = $_POST['payer'];


if(isset($_POST['credit-submit'])){
    $insert = "INSERT INTO `credit` (`credit_date`, `credit_description`, `credit_amount`, `credit_category`) VALUES ('$creditDate' , '$creditDescription' , '$creditAmount','$payer')";

    if($_POST['payer'] === "Borrowed"){
        $insertB = "INSERT INTO `borrow` (`borrow_date`, `borrow_description`, `borrow_amount` ) VALUES ('$creditDate' , '$creditDescription' , '$creditAmount')";
        mysqli_query($conDb,$insertB);
    }

    if(mysqli_query($conDb,$insert)){
        header("Location:../add.php");
    }
    else{
        header("Location:../add.php?unsuccessfullAddition=Could not add");
    }
}



?>