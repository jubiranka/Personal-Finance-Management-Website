<?php
    session_start();
    if(isset($_POST['logoutAccount'])){
        unset($_SESSION["name"]);  
        unset($_SESSION["password"]);  
        unset($_SESSION["username"]);  
        unset($_SESSION["profilePhoto"]);  
        unset($_SESSION["databaseName"]);  
        unset($_SESSION["logIn"]);  
        header("Location: ../index.php");
    }
?>