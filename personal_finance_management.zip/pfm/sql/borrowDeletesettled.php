<?php
include_once("../sql/userConnection.php"); 

$borrowSettleDeleteId = $_GET['borrowSettleDeleteId'];
echo $borrowSettleDeleteId;



$insertBorrowSettledDelete = "DELETE FROM `borrow` WHERE `borrow_id` ='{$borrowSettleDeleteId}'";
if(mysqli_query($conDb,$insertBorrowSettledDelete)){
    header("Location:../profile.php");
}
else{
    header("Location:../add.php?unsuccessfullDeletion=Could not delete");
}

?>