<?php 
    include_once("connection.php"); 
    $expenseTable= "CREATE TABLE `expense` ( `expense_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `expense_date` DATE NOT NULL , `expense_description` VARCHAR(400) NOT NULL , `expense_amount` INT NOT NULL ,`expense_comment` VARCHAR(200) NOT NULL )";
    mysqli_query($con , $expenseTable);
    if(isset($_POST['expense-submit'])){
        $expenseDescription = $_POST['expenseDescription'];
        $expenseAmount = $_POST['expense-amount'];
        $expenseDate = $_POST['expense-date'];
        $expenseInsert = "INSERT INTO `expense` (`expense_description`,`expense_amount`,`expense_date`) VALUES ('$expenseDescription','$expenseAmount','$expenseDate')";
        if(mysqli_query($con,$expenseInsert)){
            echo "inserted";
        }
    }
?>