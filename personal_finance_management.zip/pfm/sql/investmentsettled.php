<?php
include_once("../sql/userConnection.php"); 

$investmentSettleId = $_GET['investmentSettleId'];
echo $investmentSettleId;



$insertinvestmentSettledDelete = "DELETE FROM `investment` WHERE `investment_id` ='{$investmentSettleId}'";
if(mysqli_query($conDb,$insertinvestmentSettledDelete)){
    header("Location:../profile.php");
}
else{
    header("Location:../add.php?unsuccessfullDeletion=Could not delete");
}

?>