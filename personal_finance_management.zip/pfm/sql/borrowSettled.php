<?php
include_once("../sql/userConnection.php"); 

$borrowSettleId = $_GET['borrowSettleId'];
echo $borrowSettleId;



$insertBorrowSettled = "UPDATE `borrow` SET `status` = 'settled' WHERE `borrow_id` = '{$borrowSettleId}'";
if(mysqli_query($conDb,$insertBorrowSettled)){
    header("Location:../profile.php");
}
else{
    header("Location:../add.php?unsuccessfullSettlement=Could not settle");
}

?>