<?php
include_once("../sql/userConnection.php");
$splitExpenseDescription = $_POST['splitExpenseDescription'];
$splitExpenseDate = $_POST['splitExpense-date'];
$splitExpenseAmount = $_POST['splitExpense-amount'];
$paidBy = $_POST['paidBy'];
$splitBtw = $_POST['splitBtw'];

$splitPartyName = [];
$partyName = 'splitPartyName';
for ($i=1; $i < $splitBtw; $i++) { 
    $partyName .= (string)$i; 
    $splitPartyName[$i] = $_POST[$partyName];
    $partyName = 'splitPartyName';
}

$splitSharePerHead = (int)$splitExpenseAmount / (int)$splitBtw;



if(isset($_POST['split-submit'])){
    if($paidBy == "you"){
        for ($i=1; $i < $splitBtw; $i++) { 
            $insertSplitLent = "INSERT INTO `lent` (`lent_date`, `lent_description`, `lent_amount`, `lent_from`) VALUES ('$splitExpenseDate' , '$splitExpenseDescription' , '$splitSharePerHead','$splitPartyName[$i]')";
            $insertD = "INSERT INTO `debit` (`debit_date`, `debit_description`, `debit_amount`, `debit_category`) VALUES ('$splitExpenseDate' , '$splitExpenseDescription' , '$splitSharePerHead','Lent')";
            if(mysqli_query($conDb,$insertSplitLent) && mysqli_query($conDb,$insertD)){
                header("Location:../add.php");
            }
            else{
                header("Location:../add.php?unsuccessfullSplit=Could not Split");
            }
        }


    }
    else if($paidBy == "others"){
        $othersPayee = $_POST['othersPayee'];
        echo "<script> console.log('$othersPayee'); </script>";
        $insert = "INSERT INTO `borrow` (`borrow_date`, `borrow_description`, `borrow_amount`, `borrowed_from`) VALUES ('$splitExpenseDate' , '$splitExpenseDescription' , '$splitSharePerHead','$othersPayee')";

        $insertI = "INSERT INTO `credit` (`credit_date`, `credit_description`, `credit_amount`, `credit_category`) VALUES ('$splitExpenseDate' , '$splitExpenseDescription' , '$splitSharePerHead','Borrowed')";


        if(mysqli_query($conDb,$insert) && mysqli_query($conDb,$insertI)){
            header("Location:../add.php");
            echo("fghjk");
        }
        else{
            header("Location:../add.php?unsuccessfullSplit=Could not Split");
        }

    }
}
?>