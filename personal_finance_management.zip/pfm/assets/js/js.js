// home page circle svg animation
var ele = document.querySelector(':root');
var circles = document.querySelectorAll("svg #front");
var circlebox = document.querySelector(".circle-box");
for (let i = 0; i < circles.length; i++) {
    circles[i].style.setProperty(`--strokeDasharray${[i]}`, `${circles[i].getTotalLength()}px`);
    circles[i].style.setProperty(`--strokeDashoffset${[i]}`, `${circles[i].getTotalLength()}px`);    
}


// media query of svg changing its size from attributes in home page
var size = window.matchMedia("(max-width:480px)");
var circle = document.querySelectorAll(".circle-box svg");
if (size.matches) {
    circle.forEach(element => {
        element.setAttribute('height','90');
        element.setAttribute('width','90');
    });
}








$(document).ready(function(){
    
// add button credit 
    $("#addCreditButton").click(function(){
        $("#addCreditForm").show();
        $("#addCreditForm").siblings().hide();
    });


// add button Debit 
$("#addDebitButton").click(function(){
    $("#addDebitForm").show();
    $("#addDebitForm").siblings().hide();
});




// add button Investment 
$("#addInvestmentButton").click(function(){
    $("#addInvestmentForm").show();
    $("#addInvestmentForm").siblings().hide();
});





// add button Borrowed 
$("#addBorrowedButton").click(function(){
    $("#addBorrowedForm").show();
    $("#addBorrowedForm").siblings().hide();
});



// add button Lend 
$("#addLendButton").click(function(){
    $("#addLendForm").show();
    $("#addLendForm").siblings().hide();
});








// check if any field is empty in split form of add page
$('.fa-equals').click(function(){
    if($('[name="splitExpenseDescription"]').val() || $('[name="splitExpense-date"]').val() || $('[name="splitExpense-amount"]').val() || $('[name="paidBy"]').val()){
        $('#divisionErr').show();
        $('#divisionErr span').text("Enter all the Inputs");
    }
});






// add split page showing the input box on choosing the others radio btn
$('#others').click(function(){
    $('#payee').show();
    // $('#others').attr('name','reset');
    // $('#payee').attr('name','paidBy');
    $('#splitBtw').on('keyup', function () {
        var othersName = $('#payee').val();
        $("[class='splitPartyName']").eq(1).val(othersName);
        $("[class='splitPartyName']").attr('disabled');
    });

});


$('#splitBtw').keyup(function(){
    $('#splitPeopleDiv').show();
});


// split divisions color change function
$('#splitDivisionDiv div i').click(function(){
    $(this).parent().addClass('bgChange');
    $(this).parent().siblings().removeClass('bgChange');    
    $(this).addClass('colorChange');
    $(this).parent().siblings().children().removeClass('colorChange');
});



// calculation of division split
$('.fa-equals').click(function(){
    $("[name='splitPartyShare']").each(function(){
        $("[name='splitPartyShare']").val('');
    });
    var equalSplitAmt = $('[name="splitExpense-amount"]').val();
    var equalSplitPeople = $('[name="splitBtw"]').val();
    var equalSplitShare = parseInt(parseInt(equalSplitAmt) / parseInt(equalSplitPeople));
    $("[name='splitPartyShare']").val(equalSplitShare);
});





// investment add system cahnges UI
$('[value="FixedDeposits"]').click(function(){
    $('[name="investment-interest"]').show();
    $('.maturityInvestmentDiv').show();
    $('#variantInterestOpt').show();
    $('#fdAbout').show();
    $('#fdAbout').siblings().hide();
});
$('[value="termDeposits"]').click(function(){
    $('[name="investment-interest"]').show();
    $('.maturityInvestmentDiv').show();
    $('#variantInterestOpt').show();
    $('#termAbout').show();
    $('#termAbout').siblings().hide();
});
$('[value="PPF"]').click(function(){
    $('[name="investment-interest"]').show();
    $('.maturityInvestmentDiv').show();
    $('#variantInterestOpt').hide();
    $('#ppfAbout').show();
    $('#ppfAbout').siblings().hide();
});
$('[value="Stocks"]').click(function(){
    $('[name="investment-interest"]').hide();
    $('.maturityInvestmentDiv').hide();
    $('#variantInterestOpt').hide();
});
$('[value="Other"]').click(function(){
    $('[name="investment-interest"]').hide();
    $('.maturityInvestmentDiv').hide();
    $('#variantInterestOpt').hide();
});







    
// side change changes of tab or li of list of message.php
    $(".debitBtn").click(function(){
        $("#debit").show();
        $("#debit").siblings().hide();
    });
    $(".creditBtn").click(function(){
        $("#credit").show();
        $("#credit").siblings().hide();
    });
    $(".borrowedBtn").click(function(){
        $("#borrowed").show();
        $("#borrowed").siblings().hide();
    });
    $(".investmentBtn").click(function(){
        $("#investments").show();
        $("#investments").siblings().hide();
    });
    $(".savingBtn").click(function(){
        $("#savings").show();
        $("#savings").siblings().hide();
    });
    $(".lendBtn").click(function(){
        $("#lend").show();
        $("#lend").siblings().hide();
    });    
    $(".reportBtn").click(function(){
        $("#report").show();
        $("#report").siblings().hide();
    });
    
    // $(".splitShowBtn").click(function(){
    //     $("#splitShow").show();
    //     $("#splitShow").siblings().hide();
    // });





// side change changes of tab or li of list of add.php
$(".addDebitBtn").click(function(){
    $("#addDebitForm").show();
    $("#addDebitForm").siblings().hide();
});
$(".addCreditBtn").click(function(){
    $("#addCreditForm").show();
    $("#addCreditForm").siblings().hide();
});
$(".addInvestmentBtn").click(function(){
    $("#addInvestmentForm").show();
    $("#addInvestmentForm").siblings().hide();
});
$(".addBorrowedBtn").click(function(){
    $("#addBorrowedForm").show();
    $("#addBorrowedForm").siblings().hide();
});
$(".addLendBtn").click(function(){
    $("#addLendForm").show();
    $("#addLendForm").siblings().hide();
});
// $(".addFriendBtn").click(function(){
//     $("#friends").show();
//     $("#friends").siblings().hide();
// });
$(".addSplitBtn").click(function(){
    $("#splitExpenseForm").show();
    $("#splitExpenseForm").siblings().hide();
});










// small device menu for message page 
    // on menu icon click
    $('.table .mediaMenu .fa-bars').click(function(){
        $('.table .side-list-menu').removeClass('d-none');
    });


    // on x icon click
    $('.table .side-list-menu .fa-x').click(function(){
        $('.table .side-list-menu').addClass('d-none');
    });


    // on list item click
    $('.table .side-list-menu ul li').click(function(){
        $('.table .side-list-menu').addClass('d-none');
    })










// small device menu for message page 
    // on menu icon click
    $('.addTable .mediaMenu .fa-bars').click(function(){
        $('.addTable .side-list-menu').removeClass('d-none');
    });


    // on x icon click
    $('.addTable .side-list-menu .fa-x').click(function(){
        $('.addTable .side-list-menu').addClass('d-none');
    });


    // on list item click
    $('.addTable .side-list-menu ul li').click(function(){
        $('.addTable .side-list-menu').addClass('d-none');
    });
















// regex validation for newUser form
    var $regexname=/^([a-zA-Z]{3,})$/;
    $('[name="userName"]').on('keypress keydown keyup',function(){
             if (!$(this).val().match($regexname)) {
              // there is a mismatch, hence show the error message
                 $('[name="userName"]').next().removeClass('d-none');
             }
           else{
                // else, do not display message
                $('[name="userName"]').next().addClass('d-none');
               }
         });


    var $regexContact = /^[6789]\d{9}$/;
    $('[name="userContact"]').on('keypress keydown keyup',function(){
        if (!$(this).val().match($regexContact)) {
         // there is a mismatch, hence show the error message
            $('[name="userContact"]').next().removeClass('d-none');
        }
      else{
           // else, do not display message
           $('[name="userContact"]').next().addClass('d-none');
          }
    });



    var $regexEMail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/;
    $('[name="userEMail"]').on('keypress keydown keyup',function(){
        if (!$(this).val().match($regexEMail)) {
         // there is a mismatch, hence show the error message
            $('[name="userEMail"]').next().removeClass('d-none');
        }
      else{
           // else, do not display message
           $('[name="userEMail"]').next().addClass('d-none');
          }
    });



    var $regexPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$#!%*?&]{8,}$/;
    $('[name="userPassword"]').on('keypress keydown keyup',function(){
        if (!$(this).val().match($regexPassword)) {
         // there is a mismatch, hence show the error message
            $('[name="userPassword"]').next().removeClass('d-none');
        }
      else{
           // else, do not display message
           $('[name="userPassword"]').next().addClass('d-none');
          }
    });






// setting side change three bars show and hide
$(".nameBtn").click(function(){
    $("#settingName").show();
    $("#settingName").siblings().hide();
});
$(".usernameBtn").click(function(){
    $("#settingUsername").show();
    $("#settingUsername").siblings().hide();
});
$(".passwordBtn").click(function(){
    $("#settingPassword").show();
    $("#settingPassword").siblings().hide();
});
$(".deleteBtn").click(function(){
    $("#settingDelete").show();
    $("#settingDelete").siblings().hide();
});
$(".logoutBtn").click(function(){
    console.log("dfgchjbkn");
    $("#settingLogout").show();
    $("#settingLogout").siblings().hide();
});
$(".appearanceBtn").click(function(){
    $("#settingApperance").show();
    $("#settingApperance").siblings().hide();
});




// apperance change code didn't work
// $('#checkbox').on('change', function() {
//     console.log("fegvcbdhnjxm");
//     $('body').css('--dark-white', '#626060');
//     $('body').css('--dark-grey', '#f1f1f1');
//     $('body').css('--some-white', '#585657');
//     $('body').css('--black-grey', '#EBEBEB');
//     $('body').css('--black', '#D9D9D9');
//   });




// setting page side change name change button event on click
$('#changeNameBtn').click(function(){
    $('#settingName .changeData div').last().removeClass('d-none');
});

$('#changeUsernameBtn').click(function(){
    $('#settingUsername .changeData div').last().removeClass('d-none');
});
$('#passwordBtn').click(function(){
    $('#settingPassword .changeData div').last().removeClass('d-none');
});














// setting page password change regex
var $regexPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!#%*?&]{8,}$/;
$('#newPassword').on('keypress keydown keyup',function(){
    if (!$(this).val().match($regexPassword)) {
     // there is a mismatch, hence show the error message
        $('#newPassword').next().removeClass('d-none');
    }
  else{
       // else, do not display message
       $('#newPassword').next().addClass('d-none');
      }
});

// setting password change verification
$('#newPassword').keyup(function(){
    $newPasswordVal = $('#newPassword').val();
    $('#newPasswordVerify').on('keypress keydown keyup',function(){
        if (!$(this).val().match($newPasswordVal)) {
         // there is a mismatch, hence show the error message
         console.log($newPasswordVal);
            $('#newPasswordVerify').next().removeClass('d-none');
        }
      else{
           // else, do not display message
           console.log($newPasswordVal);
           $('#newPasswordVerify').next().addClass('d-none');
          }
    });
})











});



// edit changes javascript
// const addEditChangeButton = document.getElementById('addEditChangeButton');
// addEditChangeButton.addEventListener('click',()=>{

// })






